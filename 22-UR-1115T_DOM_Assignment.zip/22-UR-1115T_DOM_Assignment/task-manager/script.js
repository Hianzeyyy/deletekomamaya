// =====================================================================
// Section F - Interactive Task Manager (script.js)
// Student: Lorenzo, Mhel Pablo | 22-UR-1115T | BSIT 3rd Year
// =====================================================================
"use strict";

// ---------------------------------------------------------------------
// BONUS 1: small helper library wrapping the native DOM methods.
// $ and $$ are used for some selections, create() builds the task items.
// create() uses textContent / createTextNode only, never innerHTML.
// ---------------------------------------------------------------------
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

function create(tag, attrs = {}, ...children) {
  const element = document.createElement(tag);
  Object.entries(attrs).forEach(([name, value]) => {
    if (name === "class") element.className = value;
    else if (name === "text") element.textContent = value;
    else if (name === "dataset") Object.assign(element.dataset, value);
    else element.setAttribute(name, value);
  });
  children.forEach((child) => {
    element.append(typeof child === "string" ? document.createTextNode(child) : child);
  });
  return element;
}

// ---------------------------------------------------------------------
// Selecting (getElementById, querySelector, querySelectorAll all used)
// ---------------------------------------------------------------------
const taskInput = document.getElementById("task-input");
const addBtn = document.getElementById("add-btn");
const message = document.getElementById("message");
const taskList = document.getElementById("task-list");
const counter = document.getElementById("counter");
const clearBtn = document.getElementById("clear-btn");
const filterBar = document.querySelector(".filters");

let currentFilter = "all";
const STORAGE_KEY = "dom-assignment-tasks";

// ---------------------------------------------------------------------
// Messages (changes an element's text AND its inline style)
// ---------------------------------------------------------------------
let messageTimer = null;
function showMessage(text, colour) {
  message.textContent = text;
  message.style.color = colour; // inline style change
  clearTimeout(messageTimer);
  messageTimer = setTimeout(() => {
    message.textContent = "";
  }, 2500);
}

// ---------------------------------------------------------------------
// Add button is disabled while the input is empty (attribute methods)
// ---------------------------------------------------------------------
function updateAddButton() {
  if (taskInput.value.trim() === "") {
    addBtn.setAttribute("disabled", "");
  } else {
    addBtn.removeAttribute("disabled");
  }
}

// ---------------------------------------------------------------------
// Create one task <li>: text + Done + Delete
// ---------------------------------------------------------------------
function createTaskItem(text, isDone = false) {
  const li = create(
    "li",
    { class: "task", dataset: { status: "pending" } },
    create("span", { class: "task-text", text: text, title: "Double-click to edit" }),
    create(
      "div",
      { class: "task-actions" },
      create("button", { type: "button", class: "done-btn", text: "Done" }),
      create("button", { type: "button", class: "delete-btn", text: "Delete" })
    )
  );
  setDone(li, isDone);
  return li;
}

// Done state: class for the look, data-status attribute for the data
function setDone(li, done) {
  li.classList.toggle("completed", done);
  li.dataset.status = done ? "done" : "pending";
}

// ---------------------------------------------------------------------
// Counter, filter, save
// ---------------------------------------------------------------------
function updateCounter() {
  const remaining = taskList.querySelectorAll("li:not(.completed)").length;
  counter.textContent = `${remaining} ${remaining === 1 ? "task" : "tasks"} remaining`;
}

function applyFilter() {
  $$(".task", taskList).forEach((li) => {
    const isDone = li.classList.contains("completed");
    const show =
      currentFilter === "all" ||
      (currentFilter === "active" && !isDone) ||
      (currentFilter === "completed" && isDone);
    li.hidden = !show; // hidden attribute
  });
}

// BONUS 3: save to / load from localStorage
function saveTasks() {
  try {
    const data = $$(".task", taskList).map((li) => ({
      text: li.firstElementChild.textContent,
      done: li.dataset.status === "done",
    }));
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.warn("Could not save tasks:", error.message);
  }
}

function loadTasks() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    saved.forEach((item) => taskList.append(createTaskItem(item.text, item.done)));
  } catch (error) {
    console.warn("Could not load tasks:", error.message);
  }
}

// one function to call after any change
function refresh() {
  applyFilter();
  updateCounter();
  saveTasks();
}

// ---------------------------------------------------------------------
// 1. Add a task (empty input is rejected)
// ---------------------------------------------------------------------
function addTask() {
  const text = taskInput.value.trim();
  if (text === "") {
    showMessage("Please type a task first.", "#c62828");
    taskInput.focus();
    return;
  }
  taskList.append(createTaskItem(text));
  taskInput.value = "";
  updateAddButton();
  showMessage("Task added.", "#1a7f37");
  refresh();
  taskInput.focus();
}

addBtn.addEventListener("click", addTask);
taskInput.addEventListener("input", updateAddButton);
// Enter key: a disabled button cannot be clicked, so Enter on an empty
// input is where the "empty input" message is shown.
taskInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter") addTask();
});

// ---------------------------------------------------------------------
// 3 + 4. Done and Delete with event delegation on the <ul>
// ---------------------------------------------------------------------
taskList.addEventListener("click", (event) => {
  const button = event.target.closest("button");
  if (!button) return; // click was not on a button
  const li = button.closest("li");
  // button.parentElement is the actions <div>; its previous sibling is the text <span>
  const textSpan = button.parentElement.previousElementSibling;

  if (button.classList.contains("done-btn")) {
    setDone(li, !li.classList.contains("completed"));
  } else if (button.classList.contains("delete-btn")) {
    const removedText = textSpan.textContent;
    li.remove();
    showMessage(`Deleted "${removedText}".`, "#6b7280");
  }
  refresh();
});

// ---------------------------------------------------------------------
// 5. Filter buttons
// ---------------------------------------------------------------------
filterBar.addEventListener("click", (event) => {
  const button = event.target.closest(".filter-btn");
  if (!button) return;
  currentFilter = button.dataset.filter;
  $$(".filter-btn", filterBar).forEach((btn) => {
    btn.classList.toggle("selected", btn === button);
  });
  applyFilter();
});

// ---------------------------------------------------------------------
// 7. Clear Completed
// ---------------------------------------------------------------------
clearBtn.addEventListener("click", () => {
  const done = taskList.querySelectorAll("li.completed");
  done.forEach((li) => li.remove());
  showMessage(done.length === 0 ? "No completed tasks to clear." : `Cleared ${done.length} completed task(s).`,
    done.length === 0 ? "#c62828" : "#6b7280");
  refresh();
});

// ---------------------------------------------------------------------
// 8. (Bonus) Edit: double-click the text, Enter saves, Escape cancels
// ---------------------------------------------------------------------
taskList.addEventListener("dblclick", (event) => {
  const span = event.target.closest(".task-text");
  if (!span) return;

  const input = create("input", { type: "text", class: "edit-input", value: span.textContent });
  let finished = false; // stops Enter + blur from both saving
  const finish = (save) => {
    if (finished) return;
    finished = true;
    const newText = input.value.trim();
    if (save && newText !== "") span.textContent = newText;
    input.replaceWith(span);
    refresh();
  };
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") finish(true);
    else if (e.key === "Escape") finish(false);
  });
  input.addEventListener("blur", () => finish(true));

  span.replaceWith(input);
  input.focus();
  input.select();
});

// ---------------------------------------------------------------------
// Start up
// ---------------------------------------------------------------------
loadTasks();
updateAddButton();
refresh();

// BONUS 2: MutationObserver logs every add/remove in the task list.
// Started after loadTasks() so it only reports changes the user makes.
const observer = new MutationObserver((records) => {
  records.forEach((record) => {
    record.addedNodes.forEach((node) =>
      console.log("[MutationObserver] added:", node.firstElementChild.textContent));
    record.removedNodes.forEach((node) =>
      console.log("[MutationObserver] removed:", node.firstElementChild.textContent));
  });
});
observer.observe(taskList, { childList: true });
